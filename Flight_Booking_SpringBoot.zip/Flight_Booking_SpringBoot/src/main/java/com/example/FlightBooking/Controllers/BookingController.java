package com.example.FlightBooking.Controllers;

public class BookingController {
}
