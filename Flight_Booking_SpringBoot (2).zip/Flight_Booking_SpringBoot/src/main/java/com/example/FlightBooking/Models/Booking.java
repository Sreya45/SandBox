package com.example.FlightBooking.Models;

public class Booking {
}
