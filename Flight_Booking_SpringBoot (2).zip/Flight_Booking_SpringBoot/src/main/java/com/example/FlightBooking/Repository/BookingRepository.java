package com.example.FlightBooking.Repository;

public interface BookingRepository {
}
